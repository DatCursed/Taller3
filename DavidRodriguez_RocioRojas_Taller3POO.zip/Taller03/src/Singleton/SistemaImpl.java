package Singleton;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import Factory.ProyectoFactory;
import Factory.TareaFactory;
import Factory.UsuarioFactory;
import Logica.Proyecto;
import Logica.Sistema;
import Logica.Tarea;
import Logica.Usuario;
import Strategy.ComplejidadStrategy;
import Strategy.FechaStrategy;
import Strategy.ImpactoStrategy;
import Strategy.Strategy;
import Visitor.VisitorImpl;
import Visitor.Visitor;

public class SistemaImpl implements Sistema {
	private static SistemaImpl instance;
	
	private ArrayList<Tarea> tareas = new ArrayList<>();
	private ArrayList<Proyecto> proyectos = new ArrayList<>();
	private ArrayList<Usuario> usuarios = new ArrayList<>();
	
	private Usuario usuario;
	
	/**
	 * Constructor de la clase SistemaImpl.
	 */
	private SistemaImpl() {
	}

	/**
	 * Método que crea una instancia unica del Sistema (Singleton).
	 * @return
	 */
	public static Sistema getInstance() {
		if (instance == null) {
			instance = new SistemaImpl(); 
		}
		return instance;
	}
	
	/**
	 * Método que permite iniciar sesión.
	 * @param username - indica el nombre del usuario.
	 * @param contraseña - indica la contraseña del usuario.
	 * @return
	 */
	@Override
	public void buildUsuario(String[] parts) {
		UsuarioFactory factory = new UsuarioFactory();
		Usuario usuario = factory.buildUsuario(parts);
		usuarios.add(usuario);
	}
	
	/**
	 * Método que permite iniciar sesión.
	 * @param username - indica el nombre del usuario.
	 * @param contraseña - indica la contraseña del usuario.
	 * @return
	 */
	@Override
	public boolean login(String username, String contraseña) {
		Usuario u = buscarUsuario(username);
		
		if (u == null) return false;
		
		if (!u.getContraseña().equals(contraseña)) return false;
		
		usuario = u;
		return true;
	}
	
	/**
	 * Método que permite conseguir el rol de un usuario.
	 * @return
	 */
	@Override
	public String getUsuarioRol() {
		return usuario.getRol().toUpperCase();
	}
	
	/**
	 * Método que sirve para buscar un usuario según su username.
	 * @param username - indica el nombre de usuario.
	 * @return
	 */
	@Override
	public Usuario buscarUsuario(String username) {
		for (Usuario u: usuarios) {
			if (u.getUsername().equalsIgnoreCase(username)) {
				return u;
			}
		}
		return null;
	}
	
	/**
	 * Método que permite validar que existen usuarios.
	 * @return
	 */
	@Override
	public boolean existenUsuarios() {
		return !usuarios.isEmpty();
		
	}
	
	/**
	 * Método que construye proyectos.
	 * @param parts - vector que corresponde al archivo "proyectos.txt".
	 */
	@Override
	public void buildProyectos(String[] parts) {
		ProyectoFactory factory = new ProyectoFactory();
		Proyecto proyecto = factory.buildProyecto(parts);
		proyectos.add(proyecto);
	}
	
	/**
	 * Método que permite conocer el responsable de un proyecto.
	 * @param p - indica un objeto de la clase Proyecto.
	 * @return
	 */
	@Override
	public Usuario getResponsableProyecto(Proyecto p) {
		return buscarUsuario(p.getResponsable());
	}
	
	/**
	 * Método que construye tareas.
	 * @param parts - vector que corresponde al archivo "tareas.txt".
	 */
	@Override
	public void buildTareas(String[] parts) {
		TareaFactory factory = new TareaFactory();
		Tarea tarea = factory.buildTarea(parts);
		tareas.add(tarea);
	}
	
	/**
	 * Método que permite ver la lista completa de proyectos.
	 * @return
	 */
	@Override
	public String verListaCompleta() {
		String aux = "";
		
		for (Proyecto p: proyectos) {
			aux += "Proyecto: " + p;
			
			boolean existeTarea = false;
			
			for (Tarea t: tareas) {
				if (t.getIdProyecto().equalsIgnoreCase(p.getId())) {
					existeTarea = true;
					
					aux += "Tarea: " + t;
				}
			}
			
			if (!existeTarea) {
				aux += "No hay tareas en este proyecto.";
			}
			aux += "\n";
		}
		return aux;
	}
	
	/**
	 * Método que permite agregar proyectos.
	 * @param nombre - indica el nombre del proyecto.
	 * @param responsable - indica el responsable del proyecto.
	 * @return
	 */
	@Override
	public String agregarProyecto(String nombre, String responsable) {
		Usuario u = buscarUsuario(responsable);
		if (u == null) {
			return "Error. El responsable no existe.";
		}
		
		int numero = proyectos.size() + 1;
		String nuevoID = String.format("PR%03d", numero);
		
		Proyecto p = new Proyecto(nuevoID, nombre, responsable);
		proyectos.add(p);
		
		return "Proyecto agregado: " + p.getId();
	}
	
	/**
	 * Método que permite eliminar proyectos.
	 * @param id - indica el id del proyecto.
	 * @return
	 */
	@Override
	public String eliminarProyecto(String id) {
		Proyecto p = buscarProyecto(id);
		
		if (p == null) {
			return "Error. Proyecto no encontrado.";
		}
		
		proyectos.remove(p);
		
		return "Proyecto " + id + " eliminado junto a sus tareas."; 
	}

	/**
	 * Método que permite agregar una tarea a un proyecto.
	 * @param proyecto - id del proyecto.
	 * @param tipo - tipo de tarea.
	 * @param descripcion - descripcion de la tarea.
	 * @param estado - estado de la tarea.
	 * @param responsable - responsable de la tarea.
	 * @return
	 */
	@Override
	public String agregarTareaProyecto(String idProyecto, String tipo, String descripcion, String estado, String responsable) {
		Usuario u = buscarUsuario(responsable);
		
		if (u == null) {
			return "No se encontró al usuario.";
		}
		
		Proyecto p = buscarProyecto(idProyecto);
		
		if (p == null) {
			return "No hay proyectos asignados a este usuario.";
		}

		int numero = tareas.size() + 1;
		String nuevoID = String.format("T%07d", numero);
		String fecha = java.time.LocalDate.now().toString();
		
		for (Tarea t: tareas) {
			if (t.getResponsable().equalsIgnoreCase(responsable) && t.getFecha().equals(fecha)) {
				return "Error. El Usuario " + responsable + " ya tiene una tarea asignada a esta Fecha: " + fecha;
			}
		}
		
		String[] parts = {p.getId(), nuevoID, tipo, descripcion, estado, responsable, "Media", fecha};
		
		TareaFactory factory = new TareaFactory(); 
		Tarea t	= factory.buildTarea(parts);
		
		p.addTareaProyecto(t);
		return "Tarea agregada correctamente. ID: " + nuevoID; 
	}
	
	/**
	 * Método que permite eliminar una tarea de un proyecto.
	 * @param proyecto - id del proyecto.
	 * @param id - id de la tarea.
	 * @return
	 */
	@Override
	public String eliminarTareaProyecto(String idProyecto, String id) {
		Proyecto p = buscarProyecto(idProyecto);
		
		if (p == null) {
			return "No se encontró el proyecto.";
		}
		
		for (Tarea t: p.getTareasProyecto()) {
			if (t.getId().equalsIgnoreCase(id)) {
				p.removeTareaProyecto(t);
				return "Se eliminó la tarea " + id + " del proyecto " + p.getNombre();
			}
		}
		
		return "Error. Tarea no encontrada"; 
	}
	
	
	/**
	 * Método que busca un proyecto según su id.
	 * @param idProyecto - id del proyecto.
	 * @return
	 */
	private Proyecto buscarProyecto(String idProyecto) {
		for (Proyecto p: proyectos) {
			if (p.getId().equalsIgnoreCase(idProyecto)) {
				return p;
			}
		}
		return null;
	}
	
	/**
	 * Método que asigna prioridades.
	 * @param tipo - tipo de tarea.
	 * @param idProyecto - id del proyyecto.
	 * @return
	 */
	@Override
	public String asignarPrioridades(String tipo, String idProyecto) {
		Proyecto p = buscarProyecto(idProyecto);
		
		if (p == null) {
			return "El proyecto no se ha encontrado";
		}
		
		if (p.getTareasProyecto().isEmpty()) {
			return "El proyecto no tiene tareas";
		}
		
		for (Tarea t: p.getTareasProyecto()) {
			Strategy estrategia;
			
			switch (tipo.toLowerCase()) {
			case "impacto":
				estrategia = new ImpactoStrategy(t);
				break;
			case "complejidad":
				estrategia = new ComplejidadStrategy(t);
				break;
			case "fecha":
				estrategia = new FechaStrategy(t);
				break;
			default:
				return "Estrategia desconocida";
			}

			t.setEstrategia(estrategia);
			t.setPrioridad(estrategia.calcularPrioridad());
			
		}
		
		p.getTareasProyecto().sort((t1, t2) -> Integer.compare(t1.getPrioridad(), t2.getPrioridad()));
		
		return "Prioridades asignadas y tareas ordenadas correctamente.";
	}
	
	/**
	 * Método que genera reportes usando el archivo reporte.txt
	 * @return
	 */
	@Override
	public String generarReporte() {
		try {
			FileWriter fw = new FileWriter("reporte.txt");
			PrintWriter pw = new PrintWriter(fw);
			
			pw.println("=== REPORTE DE PROYECTOS ===\n");
			
			for (Proyecto p: proyectos) {
				pw.println("Proyecto ID: " + p.getId());
				pw.println("Nombre: " + p.getNombre());
				pw.println("Responsable: " + p.getResponsable());
				pw.println("Cantidad de tareas: " + p.getTareasProyecto().size());
				
				pw.println("--- TAREAS ---");
				
				if (p.getTareasProyecto().isEmpty()) {
					pw.println("No hay tareas en este proyecto.\n");
				} else {
					for (Tarea t: p.getTareasProyecto()) {
						pw.println("	ID: " + t.getId());
						pw.println("	Tipo: " + t.getTipo());
						pw.println("	Descripción: " + t.getDescripcion());
						pw.println("	Estado: " + t.getEstado());
						pw.println("	Responsable: " + t.getResponsable());
						pw.println("	Complejidad: " + t.getComplejidad());
						pw.println("	Fecha de creación: " + t.getFecha());
						pw.println("	--------------------");
					}
					pw.println();
				}
			}
			pw.close();
			return "Reporte generado correctamente en reporte.txt";
		} catch (Exception e) {
			return "Error al generar el reporte";
		}
	}
	
	/**
	 * Método que permite ver los proyectos del usuario.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	@Override
	public String verProyectos(String username) {
		Usuario u = buscarUsuario(username);
		
		if (u == null) {
			return "Error. Usuario no encontrado.";
		}
		
		if (u.getProyectosUsuario().isEmpty()) {
			return "No tiene proyectos asignados.";
		}
		
		String aux =  "*** PROYECTOS ***\n";
		
		for (Proyecto p: u.getProyectosUsuario()) {
			aux += "Proyecto: " + p + "\n";
		}
		
		return aux;
	}
	
	/**
	 * Método que permite ver las tareas del usuario.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	@Override
	public String verTareas(String username) {
		Usuario u = buscarUsuario(username);
		
		if (u == null) {
			return "Error. Usuario no encontrado";
		}
		
		String aux =  "*** TAREAS ***\n";
		boolean existeTarea = false;
		
		for (Tarea t: tareas) {
			if (t.getResponsable().equalsIgnoreCase(username)) {
				aux += "Tarea: " + t + "\n";
				existeTarea = true;
			}
		}
		
		if (!existeTarea) {
			aux += "No tiene tareas asignadas.\n";
		}
		
		return aux;
	}
	
	/**
	 * Método que permite acutalizar la tarea según su estado.
	 * @param username - indica el nombre del usuario.
	 * @param idTarea - id de la tarea.
	 * @param nuevoEstado - nuevo estado de la tarea.
	 * @return
	 */
	@Override
	public String actualizarEstadoTarea(String username, String idTarea, String nuevoEstado) {
		Usuario u = buscarUsuario(username);
		
		if (u == null) {
			return "Error. Usuario no encontrado";
		}
		
		for (Proyecto p: u.getProyectosUsuario()) {
			for (Tarea t: p.getTareasProyecto()) {
				if (t.getId().equalsIgnoreCase(idTarea) && t.getResponsable().equalsIgnoreCase(username)) {
					t.setEstado(nuevoEstado);
					return "Estado de tarea actualizado correctamente.";
				}
			}
		}
		
		return "Error. La tarea no existe o no pertenece al usuario";
	}
	
	/**
	 * Método que aplica Visitor a las tareas.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	@Override
	public String aplicarVisitorTareas(String idProyecto) {
		Proyecto p = buscarProyecto(idProyecto);
		
		if (p == null) {
			return "Proyecto no encontrado.";
		}
		
		Visitor visitor = new VisitorImpl();
		
		for (Tarea t: p.getTareasProyecto()) {
			t.accept(visitor);
		}
		
		return "Visitor aplicado correctamente.\n" + "Criticidad: " + p.getCriticidad() + "\n" + "Tiempo Estimado: " + p.getTiempoEstimado() + "\n" + "Calidad: " + p.getCalidad();
	}
	
	
	
	
	
	
}
