package Factory;

import Logica.Bug;
import Logica.Documentacion;
import Logica.Feature;
import Logica.Tarea;

public class TareaFactory {
	/**
	 * Método que construye tareas.
	 * @param parts - vector del archivo "tareas.txt"
	 * @return
	 */
	public Tarea buildTarea(String[] parts) {
		String proyecto = parts[0];
		String id = parts[1];
		String tipo = parts[2];
		String descripcion = parts[3];
		String estado = parts[4];
		String responsable = parts[5];
		String complejidad = parts[6];
		String fecha = parts[7];
		
		switch (tipo.toLowerCase()) {
		case "bug":
			return new Bug(proyecto, id, descripcion, estado, responsable, complejidad, fecha);
		case "feature":
			return new Feature(proyecto, id, descripcion, estado, responsable, complejidad, fecha);
		case "documentacion":
			return new Documentacion(proyecto, id, descripcion, estado, responsable, complejidad, fecha);
		}
		
		return null;
	}

}
