package Factory;

import Logica.Proyecto;

public class ProyectoFactory {
	/**
	 * Método que construye proyectos.
	 * @param parts - vector del archivo "proyectos.txt"
	 * @return
	 */
	public Proyecto buildProyecto(String[] parts) {
		String id = parts[0];
		String nombre = parts[1];
		String responsable = parts[2];
		
		return new Proyecto(id, nombre, responsable);
	}

}
