package Factory;

import Logica.Usuario;

public class UsuarioFactory {
	/**
	 * Método que construye usuarios.
	 * @param parts - vector del archivo "usuarios.txt"
	 * @return
	 */
	public Usuario buildUsuario(String[] parts) {
		String username = parts[0];
		String contraseña = parts[1];
		String rol = parts[2];
		
		return new Usuario(username, contraseña, rol);
	}

}
