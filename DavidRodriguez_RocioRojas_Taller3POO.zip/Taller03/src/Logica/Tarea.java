package Logica;

import Strategy.Strategy;
import Visitor.Visitor;

public abstract class Tarea {
	protected String idProyecto, id, descripcion, estado, responsable, complejidad, fecha;
	
	/**
	 * Método abstracto para conseguir el tipo.
	 * @return
	 */
	public abstract String getTipo();
	/**
	 * Método abstracto de visitor.
	 * @param visitor
	 */
	public abstract void accept(Visitor visitor);
	
	protected Strategy estrategia; 
	protected int prioridad;
	protected Proyecto proyectoAsociado;
	
	/**
	 * Constructor
	 * @param proyecto - id del proyecto
	 * @param id - id de la tarea
	 * @param descripcion - descripcion de la tarea
	 * @param estado - estado de la tarea
	 * @param responsable - responsable de la tarea
	 * @param complejidad - complejidad de la tarea
	 * @param fecha - fecha de la tarea
	 */
	protected Tarea(String idProyecto, String id, String descripcion, String estado, String responsable,
			String complejidad, String fecha) {
		this.idProyecto = idProyecto;
		this.id = id;
		this.descripcion = descripcion;
		this.estado = estado;
		this.responsable = responsable;
		this.complejidad = complejidad;
		this.fecha = fecha;
	}

	/**
	 * Getter de idProyecto.
	 * @return
	 */
	public String getIdProyecto() {
		return idProyecto;
	}

	/**
	 * Getter de id.
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * Getter de descripcion.
	 * @return
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * Getter de estado.
	 * @return
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * Getter de responsable.
	 * @return
	 */
	public String getResponsable() {
		return responsable;
	}

	/**
	 * Getter de complejidad.
	 * @return
	 */
	public String getComplejidad() {
		return complejidad;
	}

	/**
	 * Getter de fecha.
	 * @return
	 */
	public String getFecha() {
		return fecha;
	}

	/**
	 * Setter de estado
	 * @param estado - indica el estado de la tarea.
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	/**
	 * Setter de estrategia.
	 * @param estrategia - objeto de la clase Strategy.
	 */
	public void setEstrategia(Strategy estrategia) {
		this.estrategia = estrategia;
	}
	
	/**
	 * Método que indica usar una estrategia.
	 * @return
	 */
	public int usarEstrategia() {
		return estrategia.calcularPrioridad();
	}
	
	/**
	 * Getter de prioridad.
	 * @return
	 */
	public int getPrioridad() {
		return prioridad;
	}
	
	/**
	 * Setter de prioridad.
	 * @param prioridad - indica la prioridad de la tarea.
	 */
	public void setPrioridad(int prioridad) {
		this.prioridad = prioridad;
	}
	
	/** Getter de proyectoAsociado.
	 * @return
	 */
	public Proyecto getProyectoAsociado() {
		return proyectoAsociado;
	}
	
	/** Setter de proyectoAsociado.
	 * @param proyectoAsociado - objeto de la clase Proyecto.
	 */
	public void setProyectoAsociado(Proyecto proyectoAsociado) {
		this.proyectoAsociado = proyectoAsociado;
	}
	
	/**
	 * toString
	 */
	@Override
	public String toString() {
		return "Tarea [idProyecto=" + idProyecto + ", id=" + id + ", descripcion=" + descripcion + ", estado=" + estado
				+ ", responsable=" + responsable + ", complejidad=" + complejidad + ", fecha=" + fecha + ", prioridad=" + prioridad + "]";
	}
	
}
