package Logica;

import Visitor.Visitor;

public class Feature extends Tarea {

	/**
	 * Constructor
	 * @param proyecto - id del proyecto
	 * @param id - id de la tarea
	 * @param descripcion - descripcion de la tarea
	 * @param estado - estado de la tarea
	 * @param responsable - responsable de la tarea
	 * @param complejidad - complejidad de la tarea
	 * @param fecha - fecha de la tarea
	 */
	public Feature(String proyecto, String id, String descripcion, String estado, String responsable,
			String complejidad, String fecha) {
		super(proyecto, id, descripcion, estado, responsable, complejidad, fecha); 
	} 
	
	/**
	 * Getter de tipo.
	 */
	@Override
	public String getTipo() {
		return "Feature";
	}
	
	/**
	 * Método que acepta el visitor.
	 */
	@Override
	public void accept(Visitor visitor) {
		visitor.visit(this);
	}
}
