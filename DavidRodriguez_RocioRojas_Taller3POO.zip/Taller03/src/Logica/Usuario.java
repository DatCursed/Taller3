package Logica;

import java.util.ArrayList;

public class Usuario {
	private String username;
	private String contraseña;
	private String rol;
	private ArrayList<Proyecto> proyectosUsuario;
	
	/**
	 * Constructor de la clase Usuario.
	 * @param username - indica el nombre de usuario.
	 * @param contraseña - indica la contraseña del usuario.
	 * @param rol - indica el rol del usuario.
	 */
	public Usuario(String username, String contraseña, String rol) {
		this.username = username;
		this.contraseña = contraseña;
		this.rol = rol;
		this.proyectosUsuario = new ArrayList<>();
	}

	/**
	 * Getter de username.
	 * @return
	 */
	public String getUsername() {
		return username;
	}
	
	/**
	 * Getter de contraseña.
	 * @return
	 */
	public String getContraseña() {
		return contraseña;
	}
	
	/**
	 * Getter de rol.
	 * @return
	 */
	public String getRol() {
		return rol;
	}
	
	/**
	 * Getter de proyectosUsuario.
	 * @return
	 */
	public ArrayList<Proyecto> getProyectosUsuario() {
		return proyectosUsuario;
	}
	
	
	/**
	 * Método que añade proyectos al usuario.
	 * @param p - indica un objeto de la clase Proyecto.
	 */
	public void addProyectoUsuario(Proyecto p) {
		proyectosUsuario.add(p);
	}
	
	/**
	 * toString.
	 */
	@Override
	public String toString() {
		return "Usuario [username=" + username + ", contraseña=" + contraseña + ", rol=" + rol + ", proyectosUsuario="
				+ proyectosUsuario + "]";
	}
	
	
	
	
}
