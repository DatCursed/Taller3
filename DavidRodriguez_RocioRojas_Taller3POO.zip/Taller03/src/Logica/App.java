//David Rodríguez 21.806.579-1 ICCI

package Logica;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import Singleton.SistemaImpl;

public class App {
	private static Scanner s;
	private static Sistema sistema = SistemaImpl.getInstance();
	
	/**
	 * Método inicial donde se llama al menú e iniciando el programa.
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException {
		menu();
		s.close();
	}
	
	/**
	 * Menú principal.
	 * @throws FileNotFoundException
	 */
	private static void menu() throws FileNotFoundException {
		leerArchivos();
		
		s = new Scanner(System.in);
		
		if (!sistema.existenUsuarios()) {
			System.out.println("No se encontraron usuarios.");
			return;
		}
		
		System.out.println("BIENVENIDO AL SISTEMA...");
		System.out.println("=== INICIO DE SESION  ===");
		
		System.out.println("Nombre del Usuario: ");
		String username = s.nextLine().trim();

		System.out.println("Contraseña: ");
		String password = s.nextLine().trim();
		
		boolean existe = sistema.login(username, password);
		
		if (!existe) {
			System.out.println("Credenciales incorrectas.");
			return;
		}

		String rol = sistema.getUsuarioRol();
		
		switch (rol) {
		case "ADMINISTRADOR":
			menuAdmin(username, password);
			break;
		case "COLABORADOR":
			menuUsuario(username, password);
			break;
		default:
			System.out.println("Rol desconocido: " + rol);
		}
	}

	/**
	 * Método que lee los archivos.
	 * @throws FileNotFoundException
	 */
	private static void leerArchivos() throws FileNotFoundException {
		leerUsuarios();
		leerProyectos();
		leerTareas();
	}
	
	/**
	 * Método que lee el archivo tareas.txt.
	 * @throws FileNotFoundException
	 */
	private static void leerTareas() throws FileNotFoundException {
		s = new Scanner(new File("tareas.txt"));
		
		while (s.hasNextLine()) {
			String[] parts = s.nextLine().split("\\|");
			sistema.buildTareas(parts);
		}
	}

	/**
	 * Método que lee el archivo proyectos.txt.
	 * @throws FileNotFoundException
	 */
	private static void leerProyectos() throws FileNotFoundException {
		s = new Scanner(new File("proyectos.txt"));
		
		while (s.hasNextLine()) {
			String[] parts = s.nextLine().split("\\|");
			sistema.buildProyectos(parts);
		}
		
	}

	/**
	 * Método que lee el archivo usuarios.txt.
	 * @throws FileNotFoundException
	 */
	private static void leerUsuarios() throws FileNotFoundException {
		s = new Scanner(new File("usuarios.txt"));
		
		while (s.hasNextLine()) {
			String[] parts = s.nextLine().split("\\|");
			sistema.buildUsuario(parts);
		}
	}

	/**
	 * Método que abre el menú de administrador.
	 * 
	 * @param username - indica el nombre del usuario. 
	 * @param password - indica la contraseña del usuario.
	 */
	private static void menuAdmin(String username, String password) {
		int choice;
		
		do {
			System.out.println("--- BIENVENIDO AL SISTEMA ---");
			System.out.println("1. Ver lista completa de proyectos y tareas.");
			System.out.println("2. Agregar o Eliminar un proyecto.");
			System.out.println("3. Agregar o Eliminar una tarea en un proyecto.");
			System.out.println("4. Asignar prioridades con Strategy.");
			System.out.println("5. Generar reporte de proyectos.");
			System.out.println("0. Salir.");
			choice = s.nextInt();
			s.nextLine();
			
			switch (choice) {
			case 1:
				System.out.println(sistema.verListaCompleta());
				break;
			case 2:
				agregarEliminarProyecto(choice);
				break;
			case 3:
				agregarEliminarTareaProyecto(choice);
				break;
			case 4:
				asignarPrioridadesStrategy(choice);
				break;
			case 5:
				System.out.println(sistema.generarReporte());
				break;
			case 0:
				System.out.println("Saliendo...");
				break;
			default:
				System.out.println("Error. Reingresa: ");
			}
			
		} while (choice != 0);
	}
	
	/**
	 * Método que asigna prioridades usando el Patrón Strategy.
	 * @param choice - parámetro que representa una decisión.
	 */
	private static void asignarPrioridadesStrategy(int choice) {
		System.out.println("Ingresa el ID del proyecto: ");
		String idProyecto = s.nextLine().trim();
		
		do {
			System.out.println("**** SELECCIONE ESTRATEGIA DE PRIORIZACION ****");
			System.out.println("1. Por impacto (tipo de tarea).");
			System.out.println("2. Por fecha.");
			System.out.println("3. Por complejidad.");
			System.out.println("0. Para salir.");
			
			choice = s.nextInt();
			s.nextLine();
			
			String tipo = "";
			
			switch (choice) {
			case 1:
				tipo = "impacto";
				break;
			case 2:
				tipo = "fecha";
				break;
			case 3:
				tipo = "complejidad";
				break;
			case 0:
				System.out.println("Saliendo..");
				break;
			default:
				System.out.println("Error. Reingresa.");
			}
			
			String resultado = sistema.asignarPrioridades(tipo, idProyecto);
			System.out.println(resultado);
			
		} while (choice != 0);
	}

	/**
	 * Método que abre un submenu donde se eliminar o agregar una tarea de un proyecto.
	 * @param choice - parámetro que representa una decisión.
	 */
	private static void agregarEliminarTareaProyecto(int choice) {
		do {
			System.out.println("**** AGREGAR/ELIMINAR UNA TAREA DE UN PROYECTO ****");
			System.out.println("1. Agregar Tarea.");
			System.out.println("2. Eliminar Tarea.");
			System.out.println("0. Para salir.");
			choice = s.nextInt();
			s.nextLine();
			
			switch (choice) {
			case 1:
				agregarTareaProyecto();
				break;
			case 2:
				eliminarTareaProyecto();
				break;
			case 0:
				System.out.println("Saliendo..");
			default:
				System.out.println("Error. Reingresa.");
			}
			
		} while (choice != 0);
		
		
	}

	/**
	 * Método que elimina una tarea de un proyecto.
	 */
	private static void eliminarTareaProyecto() {
		System.out.println("ID del proyecto: ");
		String proyecto = s.nextLine().trim();
		
		System.out.println("ID de la tarea a eliminar: ");
		String id = s.nextLine();
		
		System.out.println(sistema.eliminarTareaProyecto(proyecto, id));
	}


	/**
	 * Método que agrega una tarea a un proyecto.
	 */
	private static void agregarTareaProyecto() {
		System.out.println("ID del proyecto: ");
		String proyecto = s.nextLine().trim();
		
		System.out.println("Tipo (Bug/Feature/Documentacion): ");
		String tipo = s.nextLine().trim();
		
		System.out.println("Descripción: ");
		String descripcion = s.nextLine().trim();
		
		System.out.println("Estado Inicial: ");
		String estado = s.nextLine().trim();
		
		System.out.println("Responsable: ");
		String responsable = s.nextLine().trim();
		
		System.out.println(sistema.agregarTareaProyecto(proyecto, tipo, descripcion, estado, responsable));
		
	}

	/**
	 * Método que abre un submenu donde se puede agregar o eliminar un proyecto.
	 * @param choice - parámetro que representa una decisión.
	 */
	private static void agregarEliminarProyecto(int choice) {
		do {
			System.out.println("**** AGREGAR/ELIMINAR UN PROYECTO ****");
			System.out.println("1. Agregar Proyecto.");
			System.out.println("2. Eliminar Proyecto.");
			System.out.println("0. Para salir.");
			choice = s.nextInt();
			s.nextLine();
			
			switch (choice) {
			case 1:
				agregarProyecto();
				break;
			case 2:
				eliminarProyecto();
				break;
			case 0:
				System.out.println("Saliendo..");
			default:
				System.out.println("Error. Reingresa.");
			}
			
		} while (choice != 0);
		
		
	}

	/**
	 * Método que elimina un proyecto.
	 */
	private static void eliminarProyecto() {
		System.out.println("ID del proyecto a eliminar: ");
		String id = s.nextLine();
		
		System.out.println(sistema.eliminarProyecto(id));
	}

	/**
	 * Método que agrega un proyecto.
	 */
	private static void agregarProyecto() {
		System.out.println("Nombre del proyecto: ");
		String nombre = s.nextLine();
		
		System.out.println("Responsable del proyecto: ");
		String responsable = s.nextLine();
		
		System.out.println(sistema.agregarProyecto(nombre, responsable));
	}

	/**
	 * Método que abre un submenu del usuario.
	 * @param username - indica el nombre del usuario.
	 * @param password - indica la contraseña del usuario.
	 */
	private static void menuUsuario(String username, String password) {
		int choice; 
		
		do {
			System.out.println("--- BIENVENIDO AL SISTEMA ---");
			System.out.println("1. Ver proyectos disponibles.");
			System.out.println("2. Ver tareas asignadas.");
			System.out.println("3. Actualizar el estado de una tarea.");
			System.out.println("4. Aplicar Visitor sobre tareas.");
			System.out.println("0. Salir.");
			choice = s.nextInt();
			s.nextLine();
			
			switch (choice) {
			case 1:
				System.out.println(sistema.verProyectos(username));
				break;
			case 2:
				System.out.println(sistema.verTareas(username));
				break;
			case 3:
				actualizarEstadoTarea(username);
				break;
			case 4:
				System.out.println(sistema.aplicarVisitorTareas(username));
				break;
			case 0:
				System.out.println("Saliendo...");
				break;
			default:
				System.out.println("Error. Reingresa: ");
			}
			
		} while (choice != 0);
	}

	/**
	 * Método que actualiza el estado de las tareas.
	 * @param username - indica el nombre del usuario.
	 */
	private static void actualizarEstadoTarea(String username) {
		System.out.println("Ingresa el ID de la Tarea: ");
		String idTarea = s.nextLine().trim();
		
		String nuevoEstado;
		boolean estadoValido = false;
		
		do {
			System.out.println("Ingresa el nuevo estado (Pendiente/En progreso/Completada)");
			nuevoEstado = s.nextLine().trim();
			
			if (nuevoEstado.equalsIgnoreCase("Pendiente") || nuevoEstado.equalsIgnoreCase("En progreso") || nuevoEstado.equalsIgnoreCase("Completada")) {
				estadoValido = true;
			}
		} while (!estadoValido);
		
		System.out.println(sistema.actualizarEstadoTarea(username, idTarea, nuevoEstado));
	}
	
}
