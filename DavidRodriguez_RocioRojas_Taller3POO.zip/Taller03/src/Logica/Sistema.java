package Logica;

public interface Sistema {
	//Usuarios
	
	/**
	 * Método que construye usuarios.
	 * @param parts - vector que corresponde al archivo "usuarios.txt".
	 */
	void buildUsuario(String[] parts);
	/**
	 * Método que permite iniciar sesión.
	 * @param username - indica el nombre del usuario.
	 * @param contraseña - indica la contraseña del usuario.
	 * @return
	 */
	boolean login(String username, String contraseña);
	/**
	 * Método que permite conseguir el rol de un usuario.
	 * @return
	 */
	String getUsuarioRol();
	/**
	 * Método que sirve para buscar un usuario según su username.
	 * @param username - indica el nombre de usuario.
	 * @return
	 */
	Usuario buscarUsuario(String username);
	/**
	 * Método que permite validar que existen usuarios.
	 * @return
	 */
	boolean existenUsuarios();
	
	//Proyectos
	
	/**
	 * Método que construye proyectos.
	 * @param parts - vector que corresponde al archivo "proyectos.txt".
	 */
	void buildProyectos(String[] parts);
	/**
	 * Método que permite conocer el responsable de un proyecto.
	 * @param p - indica un objeto de la clase Proyecto.
	 * @return
	 */
	Usuario getResponsableProyecto(Proyecto p);
	//Tareas
	
	/**
	 * Método que construye tareas.
	 * @param parts - vector que corresponde al archivo "tareas.txt".
	 */
	void buildTareas(String[] parts);
	//menu Admin
	
	/**
	 * Método que permite ver la lista completa de proyectos.
	 * @return
	 */
	String verListaCompleta();
	/**
	 * Método que permite agregar proyectos.
	 * @param nombre - indica el nombre del proyecto.
	 * @param responsable - indica el responsable del proyecto.
	 * @return
	 */
	String agregarProyecto(String nombre, String responsable);
	/**
	 * Método que permite eliminar proyectos.
	 * @param id - indica el id del proyecto.
	 * @return
	 */
	String eliminarProyecto(String id);
	/**
	 * Método que permite agregar una tarea a un proyecto.
	 * @param proyecto - id del proyecto.
	 * @param tipo - tipo de tarea.
	 * @param descripcion - descripcion de la tarea.
	 * @param estado - estado de la tarea.
	 * @param responsable - responsable de la tarea.
	 * @return
	 */
	String agregarTareaProyecto(String proyecto, String tipo, String descripcion, String estado, String responsable);
	/**
	 * Método que permite eliminar una tarea de un proyecto.
	 * @param proyecto - id del proyecto.
	 * @param id - id de la tarea.
	 * @return
	 */
	String eliminarTareaProyecto(String proyecto, String id);
	/**
	 * Método que asigna prioridades.
	 * @param tipo - tipo de tarea.
	 * @param idProyecto - id del proyyecto.
	 * @return
	 */
	String asignarPrioridades(String tipo, String idProyecto);
	/**
	 * Método que genera reportes usando el archivo reporte.txt
	 * @return
	 */
	String generarReporte();
	
	//Menu Usuario
	/**
	 * Método que permite ver los proyectos del usuario.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	String verProyectos(String username);
	/**
	 * Método que permite ver las tareas del usuario.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	String verTareas(String username);
	/**
	 * Método que permite acutalizar la tarea según su estado.
	 * @param username - indica el nombre del usuario.
	 * @param idTarea - id de la tarea.
	 * @param nuevoEstado - nuevo estado de la tarea.
	 * @return
	 */
	String actualizarEstadoTarea(String username, String idTarea, String nuevoEstado);
	/**
	 * Método que aplica Visitor a las tareas.
	 * @param username - indica el nombre del usuario.
	 * @return
	 */
	String aplicarVisitorTareas(String username);
	
}
