package Logica;

import java.util.ArrayList;

public class Proyecto {
	private String id, nombre, responsable;
	private ArrayList<Tarea> tareasProyecto;
	
	private int criticidad, tiempoEstimado, calidad;

	/**
	 * Constructor
	 * @param id - id del proyecto
	 * @param nombre - nombre del proyecto
	 * @param responsable - responsable del proyecto
	 */
	public Proyecto(String id, String nombre, String responsable) {
		this.id = id;
		this.nombre = nombre;
		this.responsable = responsable;
		this.tareasProyecto = new ArrayList<>();
	}

	/**
	 * Getter de id
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * Getter de responsable
	 * @return
	 */
	public String getResponsable() {
		return responsable;
	}

	/**
	 * Getter de tareasProyecto
	 * @return
	 */
	public ArrayList<Tarea> getTareasProyecto() {
		return tareasProyecto;
	}
	
	/**
	 * Método que añade tareas a un proyecto.
	 * @param t - objeto de la clase Tarea.
	 */
	public void addTareaProyecto(Tarea t) {
		tareasProyecto.add(t);
	}
	
	/**
	 * Método que elimina tareas de un proyecto.
	 * @param t - objeto de la clase Proyecto.
	 */
	public void removeTareaProyecto(Tarea t) {
		tareasProyecto.remove((t));
	}

	/**
	 * toString
	 */
	@Override
	public String toString() {
		return "Proyecto [id=" + id + ", nombre=" + nombre + ", responsable=" + responsable + ", tareasProyecto="
				+ tareasProyecto + "]";
	}
	
	/**
	 * Método que aumenta la criticidad.
	 */
	public void aumentarCriticidad() {
		criticidad++;
	}
	
	/**
	 * Método que aumenta el tiempo.
	 */
	public void aumentarTiempo() {
		tiempoEstimado += 2;
	}
	
	/**
	 * Método que aumenta la calidad.
	 */
	public void mejorarCalidad() {
		calidad++;
	}

	/**
	 * Getter de criticidad.
	 * @return
	 */
	public int getCriticidad() {
		return criticidad;
	}

	/**
	 * Getter de tiempoEstimado.
	 * @return
	 */
	public int getTiempoEstimado() {
		return tiempoEstimado;
	}

	/**
	 * Getter de calidad.
	 * @return
	 */
	public int getCalidad() {
		return calidad;
	}
	
}
