package Strategy;

public interface Strategy {
	/**Método que calcula la prioridad usando Strategy.
	 * @return
	 */
	int calcularPrioridad();
}
