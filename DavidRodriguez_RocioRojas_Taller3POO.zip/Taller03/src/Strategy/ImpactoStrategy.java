package Strategy;

import Logica.Tarea;

public class ImpactoStrategy implements Strategy {
	private Tarea tarea;
	
	/**
	 * Constructor
	 * @param tarea - objeto de la clase Tarea.
	 */
	public ImpactoStrategy(Tarea tarea) {
		this.tarea = tarea;
	}

	/**
	 * Método que calcula la prioridad según el tipo de la tarea.
	 */
	@Override
	public int calcularPrioridad() {
		switch (tarea.getTipo().toLowerCase()) {
		case "bug":
			return 1;
		case "feature":
			return 2;
		default:
			return 3;
		}
	}

}
