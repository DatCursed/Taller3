package Strategy;

import Logica.Tarea;

public class ComplejidadStrategy implements Strategy {
	private Tarea tarea;
	
	/**
	 * Constructor
	 * @param tarea - objeto de la clase Tarea.
	 */
	public ComplejidadStrategy(Tarea tarea) {
		this.tarea = tarea;
	}

	/**
	 * Método que calcula la prioridad según la complejidad de la tarea..
	 */
	@Override
	public int calcularPrioridad() {
		switch (tarea.getComplejidad().toLowerCase()) {
		case "alta":
			return 1;
		case "media":
			return 2;
		default:
			return 3;
		}
	}

}
