package Strategy;

import Logica.Tarea;

public class FechaStrategy implements Strategy {
	private Tarea tarea;
	
	/**
	 * Constructor
	 * @param tarea - objeto de la clase Tarea.
	 */
	public FechaStrategy(Tarea tarea) {
		this.tarea = tarea;
	}

	/**
	 * Método que calcula la prioridad según la fecha de la tarea.
	 */
	@Override
	public int calcularPrioridad() {
		return Integer.parseInt(tarea.getFecha().replace("-", ""));
	}

}
