package Visitor;

import Logica.Bug;
import Logica.Documentacion;
import Logica.Feature;
import Logica.Proyecto;

public class VisitorImpl implements Visitor {

	/**
	 * Método que aumenta la criticidad del proyecto si la tarea es Bug.
	 */
	@Override
	public void visit(Bug bug) {
		Proyecto p = bug.getProyectoAsociado();
		p.aumentarCriticidad();

	}
	
	/**
	 * Método que aumenta el tiempo del proyecto si la tarea es Feature.
	 */
	@Override
	public void visit(Feature feature) {
		Proyecto p = feature.getProyectoAsociado();
		p.aumentarTiempo();

	}
	
	/**
	 * Método que aumenta la calidad del proyecto si la tarea es Documentacion.
	 */
	@Override
	public void visit(Documentacion doc) {
		Proyecto p = doc.getProyectoAsociado();
		p.mejorarCalidad();
	}

}
