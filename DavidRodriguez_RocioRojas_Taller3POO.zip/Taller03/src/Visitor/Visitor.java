package Visitor;

import Logica.Bug;
import Logica.Documentacion;
import Logica.Feature;

public interface Visitor {
	/**
	 * Método que aplica visitor en la clase Bug.
	 * @param bug - objeto de la clase Bug.
	 */
	void visit(Bug bug);
	/**
	 * Método que aplica visitor en la clase Feature.
	 * @param feature - objeto de la clase Feature.
	 */
	void visit(Feature feature);
	/**
	 * Método que aplica visitor en la clase Documentacion.
	 * @param doc - objeto de la clase Documentacion.
	 */
	void visit(Documentacion doc);
}
